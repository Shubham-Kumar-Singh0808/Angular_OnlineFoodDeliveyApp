
export class Category{
    categoryId!:number;
    name!:string;
  }
  