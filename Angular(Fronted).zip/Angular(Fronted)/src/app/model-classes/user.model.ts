export class User{
    userId!:number;
    name!:string;
    email!:string;
    mobileNumber!:string;
    password!:string;
    
}